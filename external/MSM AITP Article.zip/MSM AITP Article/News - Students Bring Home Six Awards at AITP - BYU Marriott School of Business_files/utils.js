jQuery(document).ready(function($) {
    $(document.body).on("click", "a", function () {
        return handleExternalLink($(this));
    });

    function handleExternalLink(a) {
        var url = getDomAttr(a, "href");

        if (url) {
            // Link starts with http or https
            if (url.indexOf("http://") === 0 || url.indexOf("https://") === 0) {
                // Link is not to our server
                if (url.indexOf(location.hostname) === -1) {
                    // Add target works better for popup blockers
                    a.attr("target", "_blank");
                    a.attr("rel", "noopener noreferrer")
                }
            }
        }

        return true;
    }

    hidePageLoaderOverlay();

    $(".msm-page-loader").not("form").on("click", function() {
        showPageLoaderOverlay(2000);
    });

    // Keep forms from being submitted multiple times
    $(document).on("submit", "form", function () {
        // Store the form DOM element
        var form = $(this);

        // Make sure the form hasn't been submitted yet
        if (form.data("msbSubmitted") !== true) {
            // Only prevent multiple submissions if a nonce exists as this breaks some forms
            if (form.find("#msb-gen").length) {
                // Track if form has been submitted
                form.data("msbSubmitted", true);
            }

            // If has the page loader class display the loading overlay
            if (form.hasClass("msm-page-loader")) {
                showPageLoaderOverlay(2000);
            }

            return true;
        }
        else {
            // If the user tries to submit the form multiple times, show the loading overlay
            showPageLoaderOverlay(0);
        }

        return false;
    });

    function showPageLoaderOverlay(wait) {
        // Make certain overlay isn't showing already
        if ($(document).data("msbOverlay") !== true) {
            // Set overlay to true
            $(document).data("msbOverlay", true);

            // Create overlay HTML
            var pageLoaderOverlay =
                '<div id="msm-page-loader-overlay" style="position: fixed; top: 0; left: 0; padding: 30px 0; background-color: white; width: 100%; height: 100%; z-index: 999999; text-align: center;">' +
                '<img src="/msm/theme/blackice/img/loading.gif" alt="Loading Image" style="width: 100px; height: 100px;"/>' +
                '<p>Processing your request.</p>' +
                '<p><strong>Please do not refresh the page or click the back button.</strong></p>' +
                '</div>';

            // Append to body after wait timeout
            setTimeout(function () {
                $(document.body).append(pageLoaderOverlay);
            }, wait);
        }
    }

    function hidePageLoaderOverlay() {
        // Set overlay to false
        $(document).data("msbOverlay", false);

        // Remove overlay
        $(document.body).find("#msm-page-loader-overlay").remove();
    }

    function getDomAttr(dom, attr) {
        if (hasDomAttr(dom, attr)) {
            return $.trim(dom.attr(attr));
        }

        return null;
    }

    function hasDomAttr(dom, attr) {
        var val = dom.attr(attr);

        if (typeof val !== typeof undefined && val !== false) {
            if ($.trim(val)) {
                return true;
            }
        }

        return false;
    }
});