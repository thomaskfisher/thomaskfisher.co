jQuery(document).ready(function ($) {
    function getSiteName () {
        // Changing this reference to Zend may cause data issues in Google Analytics
        var sitePath = '/Zend';

        // site_url included on page :) yay global scope!
        if (typeof site_url !== 'undefined') {
            sitePath = site_url;
        }

        return (sitePath.length ? sitePath.substring(1, sitePath.length) : 'home');
    }

    $(document.body).on('click', '#primary-menu-wrapper a, ul#mobile-menu > li:not(#mobile-signin) a', function (event) {
        try {
            // Make sure the library is there before we continue
            if (typeof ga == 'function') {
                var name = $(this).text();
                var level = $(this).closest('ul').siblings('a').text();
                var parent = $(this).closest('ul.level-2-wrapper').siblings('a').text();

                if (parent == level) {
                    level = '';
                }

                var site = 'home';

                // If it is the mega menu then don't use the site, just put home
                if (!$(this).closest('#primary-menu-wrapper').hasClass('msm_home')) {
                    site = getSiteName();
                }

                ga('send', {
                    hitType: 'event',
                    eventCategory: 'Menu',
                    eventAction: site + ' > ' + (parent ? parent + ' > ' : '') + (level ? level + ' > ' : '') + name
                });
            }
        }
        catch (e) {
        }
    });

    $(document.body).on('click', '.msm-footer-content a:not(.social-media-icon)', function () {
        if (typeof ga == 'function') {
            ga('send', {
                hitType: 'event',
                eventCategory: 'Menu',
                eventAction: 'footer > ' + $(this).text()
            });
        }
    });

    $(document.body).on('click', 'a.shlider-button', function () {
        var title = $(this).closest('div.shlider-desc').siblings('div.shlider-title').text();

        if (typeof ga == 'function') {
            ga('send', {
                hitType: 'event',
                eventCategory: 'Shlider',
                eventAction: 'Button',
                eventLabel: getSiteName() + ' > ' + title + ' > ' + $(this).text()
            });
        }
    });

    $(document.body).on('click', 'li#homeburger > a', function () {
        if (typeof ga == 'function') {
            ga('send', {
                hitType: 'event',
                eventCategory: 'navigation',
                eventAction: 'homeburger'
            });
        }
    });

    $(document.body).on('click', 'li#search-icon > a', function () {
        if (typeof ga == 'function') {
            ga('send', {
                hitType: 'event',
                eventCategory: 'search',
                eventAction: 'searchIcon'
            });
        }
    });

    $(document.body).on('click', 'ul#breadcrumb a', function () {
        if (typeof ga == 'function') {
            ga('send', {
                hitType: 'event',
                eventCategory: 'navigation',
                eventAction: 'breadcrumb',
                eventLabel: getSiteName() + ' > ' + $(this).attr('title')
            });
        }
    });

    $(document.body).on('click', 'a.social-media-icon', function () {
        var blogname = $(this).data('blogname');
        var platform = $(this).data('platform');

        if (typeof ga == 'function') {
            ga('send', {
                hitType: 'event',
                eventCategory: 'socialMedia',
                eventAction: platform,
                eventLabel: blogname
            });
        }
    });

    $(document.body).on('click', 'div#action-bar a, div#apply-donate-recruit a, div#toolbar > ul > li:not([id]) a', function () {
        if (typeof ga == 'function') {
            ga('send', {
                hitType: 'event',
                eventCategory: 'actionBar',
                eventAction: $(this).text(),
                eventLabel: getSiteName()
            });
        }
    });
});