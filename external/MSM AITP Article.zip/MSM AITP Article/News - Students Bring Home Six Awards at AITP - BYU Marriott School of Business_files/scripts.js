// On page load
jQuery(document).ready(function($) {
    var menuSelector = '#primary-menu-wrapper .menu';

    // jQuery object for currently open menu. Null if all menus are closed
    var openMenuElem = null;

    // If Content Page
    if ( $('#menu-site-map').length ) {
        menuSelector = '.copy-to-mobile';
    }

    // Copy menu from desktop display to mobile display (use sidebar menu if it exists, otherwise the top-level nav)
    var menu = $(menuSelector).html();
    var html;

    $('#mobile-menu').append(menu);

    // Move contents of .level-2-wrapper (mega-menu only) up one level and remove empty .level-2-wrapper from mobile menu
    $('#mobile-menu .level-2-wrapper').each(function(){
        var wrapper = this;
        html = '';
        $('.level-2', wrapper).each(function() {
            html += $(this).html();
        });

        $(wrapper).html(html);
    });

    // Remove <ul> elements from mobile menu (they're now empty) TODO: this doesn't work the way we want
    // $('#mobile-menu .level-2-wrapper').remove();

    // Remove any list items that don't have a link (text nodes with no siblings)
    $('#mobile-menu li').contents().filter(function(){
        if (this.nodeType != 3) return false;
        if ($(this).siblings().size() != 0) return false; //it has siblings
        return true;
    }).parent().remove();

    signInInit();

    /**
     * Add drop-down arrow to all menu items with children (this code can be deleted once a server-side solution is implemented for Programs/Centers)
     */
    $('#mobile-nav-row li li').parent('ul').parent('li').not('.msm-force-open').prepend('<span class="expand"></span>');

    /**
     * Scrollbars for widget area
     */
    initScrollbar();

    function initScrollbar () {
        if(jQuery().mCustomScrollbar) {
            $('.widget-wrapper').mCustomScrollbar({
                theme: 'dark',
                axis: 'y',
                autoHideScrollbar: false,
                scrollInertia: 300,
                scrollbarPosition: 'inside',
                // These are critical to avoid the endless resize bug
                alwaysShowScrollbar: 1,
                advanced: {
                    updateOnContentResize: true
                }
            });
        }
    }

    function destroyScrollbar (){
        $('.widget-wrapper').mCustomScrollbar("destroy");
    }

    // Make tables with the stacking-table class responsive
    function responsiveTableLabels () {
        // Store the headers
        var headers = [];

        $(this).children('thead').children('tr').children('th').each(function(){
            if($(this).hasClass('msm-table-hidden-mobile')) {
                // Hide the column in stacking view
                headers.push(null);
            }
            else {
                headers.push($.trim($(this).text()));
            }
        });

        // Could not find any headers on the table, don't bother prepending headers
        if (headers.length <= 0) {
            return false;
        }

        // Prepend the header to each cell, so they can display on mobile
        $(this).children('tbody, tfoot').children('tr').each(function(){
            var colCount = 0;

            if (! $(this).hasClass('msm-table-hidden-mobile')) {
                $(this).children().each(function(){
                    // Hide for mobile
                    if (headers[colCount] == null) {
                        $(this).addClass('hidden-xs');
                    }
                    // Hide if the cell is empty
                    else if (! $.trim($(this).text())) {
                        $(this).addClass('hidden-xs');
                    }
                    // Add the header to each cell
                    else if (headers[colCount].length > 0) {
                        $(this).prepend($('<strong class="hidden-sm hidden-md hidden-lg">' + headers[colCount] + ': </strong>'));
                    }

                    // In case the cell spans multiple columns
                    colCount += this.colSpan;
                    colCount %= headers.length;
                });
            }
            else {
                $(this).addClass('hidden-xs');
            }
        });
    }

    initResponsiveTablesStacking ();

    function initResponsiveTablesStacking () {
        $('table.msm-table-stacking').each(responsiveTableLabels);
    }

    /**
     * Toolbar items on click. Closes open menu, or opens clicked menu
     */
    $(document.body).on('click', '#toolbar > ul > li > a', function(event) {
        var elemParent = $(this).parent('li');
        var wasOpen = elemParent.hasClass('open');

        if (openMenuElem) {
            closeMenu();
        }

        if (!wasOpen) {
            openMenuElem = $(this).parent('li');
            openMenu();
        }

        if ($(this).attr('href') == '' || $(this).attr('href') == '#' || ! hasAttr($(this), 'href')) {
            event.preventDefault();
            return 0;
        }
    });


    // If user clicks on a menu item inside hamburger menu
    $(document.body).on('click', '#mobile-menu a', function(event) {
        var ul = $(this).next('ul');

        //If the clicked element has children, is not the parent of current page, and the link is not empty, then toggle menu and prevent the default link behavior; otherwise follow the default behavior (i.e. follow the link)
        if (ul.length > 0 && (! $(ul).hasClass('.msm-force-open')) && ($(this).attr('href') == '' || $(this).attr('href') == '#' || ! hasAttr($(this), 'href'))) {
            toggleExpander(ul);
        }
    });

    // If user clicks on a drop-down arrow inside hamburger menu
    $(document.body).on('click', '#mobile-menu .expand, #mobile-menu .expand-sibling', function(event) {
        var ul = $(this).next('a').next('ul');

        //If the clicked element has children open/close the menu and prevent the default link behavior
        if (ul.length > 0) {
            toggleExpander(ul);
        }
    });

    // Dropdown-menu on click
    $(document.body).on('click','#primary-menu-wrapper .menu > li > a',function(event){
        // Don't display menu if this item is a link and the option has children
        if ($(this).attr('href') != '' && $(this).attr('href') != '#' && hasAttr($(this), 'href') && $(this).siblings().size() == 0) {
            return true;
        }

        // Just close if the menu clicked is already open
        if (openMenuElem == this) {
            closeMenu();
        }
        // Open the new menu
        else{
            closeMenu();
            openMenuElem = this;
            openMenu();
        }
        event.preventDefault();
        return 0;
    });

    // Close toolbar item on overlay click
    $(document.body).on('click', '#overlay, #clear-overlay, #navbar-overlay', function(){
        closeMenu();
    });

    //On browser window re-size to desktop size, hide expanding menu
    $(window).resize(function() {
        var menuOpen = $('#overlay').is(':visible');

        if (menuOpen && $('body').innerWidth() >= 992) {
            $('#overlay').hide();
            $('#mobile-nav-row>.container').hide();
            $('#mobile-nav-row .open').hide().removeClass('open');
            $('#hamburger.open').removeClass('open');
        }

        $('#overlay').css({opacity: ''});

        //close any open nav menus
        if (openMenuElem && $(openMenuElem).closest('ul').hasClass('level-1') && $('body').innerWidth() < 992) {
            closeMenu();
        }
    });

    // Open the clicked toolbar item
    function openMenu() {
        var id = $(openMenuElem).attr('id');

        if ( id == 'hamburger') {
            $('#mobile-nav-row > .container').show();
            $('#hamburger').addClass('open');
            var elem = $('.current_page_item>ul,.current_parent_item>ul');
            toggleExpander(elem, true);
        }
        else if ($(openMenuElem).closest('ul').hasClass('level-1')) {
            $(openMenuElem).addClass('open');
            $(openMenuElem).parent().children('ul').show();
            positionDropdown($(openMenuElem).parent()[0], $('#primary-menu-wrapper').hasClass('msm_home'), 20);
        }
        else {
            $(openMenuElem).addClass('open');
            $(openMenuElem).children('a').next().show();

            if (id == 'search-icon') {
                $('#search-field').focus();
            }
        }

        $('#navbar-overlay').show();
        $('#overlay').show();
    }

    // Close the open toolbar item
    function closeMenu() {
        // The bottom two lines were added to remove the classes that flip the arrows and make the bars blue
        $('.expanded-Menu').removeClass('expanded-Menu');//this gets rid of all instances of the expandedMenu class
        $('.openArrow').removeClass('openArrow');//this gets rid of all instances of the openArrow class
        if ( $(openMenuElem).attr('id') == 'hamburger') {
            $('#mobile-nav-row > .container').hide();
            $('#mobile-nav-row .open').hide().removeClass('open');
        }
        else if ($(openMenuElem).closest('ul').hasClass('level-1')) {
            $('#primary-menu-wrapper .menu>li>ul').hide().removeClass('open');
            $('#primary-menu-wrapper .menu>li>a').removeClass('open');
        }
        else {
            $(openMenuElem).children('a').next().hide();
        }

        $(openMenuElem).removeClass('open');
        openMenuElem = null;

        $('#navbar-overlay').hide();
        $('#overlay').hide();
    }

    // Hamburger menu functionality for nested expanding/collapsing menus
    function toggleExpander (ul, openOnly) {
        $('.expanded-Menu').removeClass('expanded-Menu'); // This gets rid of all instances of the expandedMenu class
        // If the element clicked is already open, close it (and its descendents)
        if ($(ul).hasClass('open') && !openOnly) {
            $(ul).siblings('.expand').removeClass('open openArrow');
            $(ul).slideUp(300).removeClass('open');
        }

        // If the element is closed, close anything open that's not a parent of the clicked element, and then open the element
        else {
            $('#mobile-nav-row .open').not($(ul).parents('ul')).siblings('.expand').removeClass('openArrow'); // This makes sure the arrows gets flipped back to the up position
            $('#mobile-nav-row .open').not($(ul).parents('ul')).slideUp(300).removeClass('open');

            $(ul).slideDown(300).addClass('open');
            $(ul).prev('a').prev('span').addClass('openArrow'); // This makes sure the correct arrow gets flipped
            $(ul).prev('a').addClass('expanded-Menu');
        }
    }

    /**
     * Dropdown menu positioning. Moves dropdown menu left or right so that it is contained within the page boundary.
     * @param menuItem - jQuery object of the parent <li> of the menu you would like to position
     * @param center - boolean. If true, the menu will be centered under its parent menu item.  Otherwise it left-aligns.
     * @param padding - integer. padding amount on left and right edge.
     */
    function positionDropdown (menuItem, center, padding) {
        var parentItem = $(menuItem);

        var dropDown = parentItem.children("ul");

        if (dropDown.position()) {
            var parentItemLeftEdge = parentItem.position().left;
            var parentItemWidth = parentItem.outerWidth();
            var parent = parentItem.parent();
            var menuWrapper = parent.parent();
            var navPadding = (menuWrapper.outerWidth() - menuWrapper.width()) / 2;

            var dropDownWidth = dropDown.outerWidth();

            // Reset the left edge (in case it was previously re-positioned)
            dropDown.css({ "left": (parentItemLeftEdge) + "px" });

            var dropLeftEdge = dropDown.position().left;

            if (center) {
                // Determine how to center the drop down below the list item
                dropLeftEdge = dropLeftEdge - ((dropDownWidth / 2) - (parentItemWidth / 2));

                // If the left position is negative we will use 20 (This is the padding I think)
                if (dropLeftEdge < (padding + navPadding)) {
                    dropLeftEdge = padding + navPadding;
                }


                // Set the left
                dropDown.css({ "left": dropLeftEdge + "px" });
            }

            // Now check the right edge
            var rightEdge = parent.outerWidth();

            var dropRightEdge = dropLeftEdge + dropDownWidth;

            dropLeftEdge = rightEdge - dropDownWidth;

            // If drop down is outside or right edge move over to the left
            if (dropRightEdge > (rightEdge - (padding - navPadding))) {
                dropDown.css({ "left": dropLeftEdge - (padding - navPadding) + "px" });
            }
        }
    }

    function signInInit() {
        jQuery.ajax({
            url: ajaxurl,
            data: {
                action: 'msm_sign_in_action',
                permalink: permalink,
                post_id: post_id
            },
            dataType: 'html',
            type: 'GET',
            xhrFields: {
                withCredentials: true
            },
            success: function (data, status) {
                jQuery('#sign-in').html(data);

                //Copy Sign-in/Tools menu to mobile menu
                var sign_in_text = $('#sign-in-text').text();
                var link = (hasAttr($('#sign-in>a'), 'href')) ? $('#sign-in>a').attr('href') : '';
                var sign_in = $('#sign-in>ul').clone();
                var expand = '';

                if (! link || link == '#') {
                    expand = '<span class="expand"></span>';
                    link = '';
                }
                else {
                    link = ' href="' + link + '"';
                }

                var wrapper = '<li id="mobile-signin" class="hidden-sm">' + expand + '<a' + link + '>'
                    + '<img class="show-normal" src="' + template_directory + '/img/profile-blue.svg" alt="Profile" />'
                    + '<img class="show-hover" src="' + template_directory + '/img/profile-light.svg" alt="Profile" />'
                    + sign_in_text + '</a></li>';
                $('#mobile-menu').prepend(wrapper);
                $('#mobile-signin').append(sign_in);
            }
        });
    }

    // Init the popover scripts on the website
    $(document.body).popover({
        selector: '[data-toggle="popover"]',
        trigger: "click",
        animation: true,
        html: true,
        placement: "auto right",
        container: "body",
        viewport: "body"
    });

    $(document.body).on("click", function (e) {
        // Labels call the click event for the associated control, this prevents that from happening
        if ($(e.target).is('label [data-toggle="popover"]')) {
            e.preventDefault();
        }

        // Close popovers when clicked off
        $(this).find('[data-toggle="popover"]').each(function () {
            //the 'is' for buttons that trigger popups
            //the 'has' for icons within a button that triggers a popup
            if (! $(this).is(e.target) && $(this).has(e.target).length === 0 &&
                $(".popover").has(e.target).length === 0) {
                $(this).popover("destroy");
            }
        });
    });

    // Remove all popovers when window is resized
    $(window).resize(function() {
        $(document.body).find('[data-toggle="popover"]').popover("destroy");
    });

    // Append an overlays to be used to make the background darker and allow you to "tap" out of a menu
    $("body").prepend('<div id="overlay" onclick="void(0);"></div>');
    $("#header-bar").prepend('<div id="navbar-overlay" onclick="void(0);"></div>');

    function getAttr(dom, attr) {
        if (hasAttr(dom, attr)) {
            return $.trim(dom.attr(attr));
        }

        return null;
    }

    function hasAttr(dom, attr) {
        var val = dom.attr(attr);

        if (typeof val !== typeof undefined && val !== false) {
            if ($.trim(val)) {
                return true;
            }
        }

        return false;
    }
});